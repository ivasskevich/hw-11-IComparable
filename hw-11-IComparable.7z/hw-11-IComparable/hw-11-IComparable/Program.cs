﻿class Person
{
    public string Name { get; set; }
    public string Surname { get; set; }
    public int Age { get; set; }
    public string Phone { get; set; }

    public Person() { }

    public Person(string name, string surname, int age, string phone)
    {
        Name = name;
        Surname = surname;
        Age = age;
        Phone = phone;
    }

    public virtual void Print()
    {
        Console.WriteLine($"Name: {Name}, Surname: {Surname}, Age: {Age}, Phone: {Phone}");
    }
}

class Student : Person, IComparable<Student>
{
    public double Average { get; set; }
    public string Number_Of_Group { get; set; }

    public Student() { }

    public Student(string name, string surname, int age, string phone, double average, string numberOfGroup)
        : base(name, surname, age, phone)
    {
        Average = average;
        Number_Of_Group = numberOfGroup;
    }

    public override void Print()
    {
        base.Print();
        Console.WriteLine($"Average: {Average}, Group: {Number_Of_Group}");
    }

    public int CompareTo(Student other)
    {
        if (other == null) return 1;

        return Average.CompareTo(other.Average);
    }
}

class Academy_Group : ICloneable
{
    private Student[] students;
    private int count;

    public Academy_Group(int size = 100)
    {
        students = new Student[size];
        count = 0;
    }

    public void Add(Student student)
    {
        if (count < students.Length)
        {
            students[count] = student;
            count++;
        }
        else
        {
            Console.WriteLine("Group is full. Cannot add more students.");
        }
    }

    public void Remove(string surname)
    {
        for (int i = 0; i < count; i++)
        {
            if (students[i].Surname == surname)
            {
                for (int j = i; j < count - 1; j++)
                {
                    students[j] = students[j + 1];
                }
                students[count - 1] = null;
                count--;
                return;
            }
        }
        Console.WriteLine("Student not found.");
    }

    public void Edit(string surname, Student updatedStudent)
    {
        for (int i = 0; i < count; i++)
        {
            if (students[i].Surname == surname)
            {
                students[i] = updatedStudent;
                return;
            }
        }
        Console.WriteLine("Student not found.");
    }

    public void Print()
    {
        for (int i = 0; i < count; i++)
        {
            students[i].Print();
        }
    }

    public void SortByAverage()
    {
        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - 1 - i; j++)
            {
                if (students[j].Average > students[j + 1].Average)
                {
                    var temp = students[j];
                    students[j] = students[j + 1];
                    students[j + 1] = temp;
                }
            }
        }
    }

    public void SortBySurname()
    {
        for (int i = 0; i < count - 1; i++)
        {
            for (int j = 0; j < count - 1 - i; j++)
            {
                if (string.Compare(students[j].Surname, students[j + 1].Surname) > 0)
                {
                    var temp = students[j];
                    students[j] = students[j + 1];
                    students[j + 1] = temp;
                }
            }
        }
    }

    public void Save(string filePath)
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            for (int i = 0; i < count; i++)
            {
                var student = students[i];
                writer.WriteLine($"{student.Name};{student.Surname};{student.Age};{student.Phone};{student.Average};{student.Number_Of_Group}");
            }
        }
    }

    public void Load(string filePath)
    {
        count = 0;
        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                var parts = line.Split(';');
                var student = new Student(parts[0], parts[1], int.Parse(parts[2]), parts[3], double.Parse(parts[4]), parts[5]);
                Add(student);
            }
        }
    }

    public Student Search(string surname)
    {
        for (int i = 0; i < count; i++)
        {
            if (students[i].Surname.Equals(surname, StringComparison.OrdinalIgnoreCase))
            {
                return students[i];
            }
        }
        Console.WriteLine("Student not found.");
        return null;
    }

    public object Clone()
    {
        Academy_Group clonedGroup = new Academy_Group(students.Length);
        for (int i = 0; i < count; i++)
        {
            var student = students[i];
            clonedGroup.Add(new Student(student.Name, student.Surname, student.Age, student.Phone, student.Average, student.Number_Of_Group));
        }
        return clonedGroup;
    }
}

class Main_Class
{
    static void Main(string[] args)
    {
        Academy_Group group = new Academy_Group();
        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Add Student");
            Console.WriteLine("2. Remove Student");
            Console.WriteLine("3. Edit Student");
            Console.WriteLine("4. Print Group");
            Console.WriteLine("5. Sort by Average");
            Console.WriteLine("6. Sort by Surname");
            Console.WriteLine("7. Save to File");
            Console.WriteLine("8. Load from File");
            Console.WriteLine("9. Search Student by Surname");
            Console.WriteLine("10. Showing how work Clone group");
            Console.WriteLine("11. Exit");
            Console.Write("Choose an option: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Surname: ");
                    string surname = Console.ReadLine();
                    Console.Write("Age: ");
                    int age = int.Parse(Console.ReadLine());
                    Console.Write("Phone: ");
                    string phone = Console.ReadLine();
                    Console.Write("Average: ");
                    double average = double.Parse(Console.ReadLine());
                    Console.Write("Group Number: ");
                    string groupNumber = Console.ReadLine();
                    group.Add(new Student(name, surname, age, phone, average, groupNumber));
                    break;

                case 2:
                    Console.Write("Enter surname of the student to remove: ");
                    string removeSurname = Console.ReadLine();
                    group.Remove(removeSurname);
                    break;

                case 3:
                    Console.Write("Enter surname of the student to edit: ");
                    string editSurname = Console.ReadLine();
                    Console.Write("New Name: ");
                    string newName = Console.ReadLine();
                    Console.Write("New Age: ");
                    int newAge = int.Parse(Console.ReadLine());
                    Console.Write("New Phone: ");
                    string newPhone = Console.ReadLine();
                    Console.Write("New Average: ");
                    double newAverage = double.Parse(Console.ReadLine());
                    Console.Write("New Group Number: ");
                    string newGroupNumber = Console.ReadLine();
                    group.Edit(editSurname, new Student(newName, editSurname, newAge, newPhone, newAverage, newGroupNumber));
                    break;

                case 4:
                    group.Print();
                    break;

                case 5:
                    group.SortByAverage();
                    Console.WriteLine("Sorted by average.");
                    break;

                case 6:
                    group.SortBySurname();
                    Console.WriteLine("Sorted by surname.");
                    break;

                case 7:
                    Console.Write("Enter file path to save: ");
                    string savePath = Console.ReadLine();
                    group.Save(savePath);
                    break;

                case 8:
                    Console.Write("Enter file path to load: ");
                    string loadPath = Console.ReadLine();
                    group.Load(loadPath);
                    break;

                case 9:
                    Console.Write("Enter surname to search: ");
                    string searchSurname = Console.ReadLine();
                    var foundStudent = group.Search(searchSurname);
                    if (foundStudent != null)
                    {
                        foundStudent.Print();
                    }
                    break;

                case 10:
                    group.Add(new Student("Alex", "Yosube", 25, "507554675488", 10, "FF44"));
                    group.Add(new Student("Lara", "Wots", 22, "89567745631199", 9, "OI89"));

                    Academy_Group clonedGroup = (Academy_Group)group.Clone();

                    Console.WriteLine("Original Group:");
                    group.Print();

                    Console.WriteLine("\nCloned Group:");
                    clonedGroup.Print();

                    Console.WriteLine("\nAdding a new student to the original group...");
                    group.Add(new Student("Moris", "Falout", 19, "396774563422", 11, "YT55"));

                    Console.WriteLine("\nOriginal Group after adding:");
                    group.Print();

                    Console.WriteLine("\nCloned Group remains unchanged:");
                    clonedGroup.Print();
                    break;

                case 11:
                    exit = true;
                    break;

                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }
}
